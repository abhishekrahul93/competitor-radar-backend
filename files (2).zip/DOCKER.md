# Docker Setup — CompetitorRadar Backend

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/abhishekrahul93/competitor-radar-backend.git
cd competitor-radar-backend

# 2. Create your .env file
cp .env.example .env
# Edit .env and add your API keys (OPENAI_API_KEY, SECRET_KEY, etc.)

# 3. Start everything
docker compose up --build -d

# 4. Check it's running
curl http://localhost:8000/health
# → {"status": "healthy", "auto_scan": "active"}
```

The API is now live at **http://localhost:8000**.

## Commands

| Command | What it does |
|---|---|
| `docker compose up --build -d` | Build & start backend + PostgreSQL |
| `docker compose down` | Stop everything |
| `docker compose logs -f backend` | Stream backend logs |
| `docker compose logs -f db` | Stream database logs |
| `docker compose restart backend` | Restart backend only |
| `docker compose --profile test run tests` | Run pytest suite |
| `docker compose down -v` | Stop & delete all data |

## Environment Variables

Set these in your `.env` file or pass them directly:

| Variable | Required | Description |
|---|---|---|
| `SECRET_KEY` | Yes | JWT signing key (use a long random string) |
| `OPENAI_API_KEY` | No | For AI briefs (OpenAI) |
| `ANTHROPIC_API_KEY` | No | For AI briefs (Anthropic) |
| `AI_PROVIDER` | No | `openai` or `anthropic` (default: openai) |
| `AI_MODEL` | No | Model name (default: gpt-4) |
| `STRIPE_SECRET_KEY` | No | For payments |
| `STRIPE_WEBHOOK_SECRET` | No | For Stripe webhooks |

The `DATABASE_URL` is set automatically by Docker Compose — no need to configure it.

## Running Tests

```bash
docker compose --profile test run tests
```

This spins up a temporary container, runs all pytest tests with an in-memory SQLite database, and exits.

## Production Notes

- Change `SECRET_KEY` to a strong random value
- Change the PostgreSQL password in `docker-compose.yml`
- Consider adding `restart: always` for production
- The database volume (`pgdata`) persists data across restarts
- Use `docker compose down -v` only if you want to wipe all data
